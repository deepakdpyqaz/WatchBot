import React from 'react'

const asdasd = () => {
  return (
    <div>asdasd</div>
  )
}

export default asdasd